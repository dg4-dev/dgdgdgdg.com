-- Introduction --

Thank you for visiting my web site and downloading this font.
Please make good use of this file.

-- font URL --

https://www.dgdgdgdg.com/works/#example

-- Author --

web : https://www.dgdgdgdg.com
email : info@dgdgdgdg.com




Secondary distribution is prohibited.
©︎ 2021 dgdgdgdg